/* ============================================================
   ZM HYBRID STORE — app logic
   Hash-router SPA. Cart/wishlist held in memory for this session
   (no localStorage, so state resets on reload — swap in a real
   backend or storage layer to persist across visits).
   ============================================================ */

/* ============================================================
   STORE CONFIG — edit these 4 lines to go live
   ============================================================ */
const CONFIG = {
  // WhatsApp number in international format, digits only, no + or spaces
  WHATSAPP_NUMBER: "923000000000",
  // Paste your Google Apps Script Web App URL here (see setup guide) to log
  // every order into a Google Sheet automatically. Leave "" to skip.
  ORDER_SHEET_WEBHOOK: "",
  // Google Analytics 4 Measurement ID, e.g. "G-XXXXXXXXXX". Leave "" to skip.
  GA_MEASUREMENT_ID: "",
  // Meta (Facebook/Instagram) Pixel ID. Leave "" to skip.
  META_PIXEL_ID: ""
};

/* ---------- ICONS (one simple line-icon per category) ---------- */
const ICONS = {
  "Health & Beauty": `<svg viewBox="0 0 64 64" fill="none" stroke="#6E1423" stroke-width="2"><rect x="24" y="10" width="16" height="10" rx="2"/><path d="M20 20h24l-2 30a4 4 0 0 1-4 4H26a4 4 0 0 1-4-4L20 20z"/><path d="M26 30h12M26 38h12"/></svg>`,
  "Home & Kitchen": `<svg viewBox="0 0 64 64" fill="none" stroke="#4d5c3a" stroke-width="2"><path d="M14 30l18-14 18 14"/><path d="M18 28v20h28V28"/><path d="M27 48v-12h10v12"/></svg>`,
  "Watches": `<svg viewBox="0 0 64 64" fill="none" stroke="#7a5b17" stroke-width="2"><circle cx="32" cy="32" r="15"/><path d="M32 24v8l6 4"/><path d="M26 8h12l-2 9H28l-2-9zM26 56h12l-2-9H28l-2 9z"/></svg>`,
  "Fragrance": `<svg viewBox="0 0 64 64" fill="none" stroke="#5c3a72" stroke-width="2"><rect x="20" y="22" width="24" height="30" rx="3"/><path d="M27 22v-6a5 5 0 0 1 10 0v6"/><path d="M20 32h24"/></svg>`,
  "Electronics": `<svg viewBox="0 0 64 64" fill="none" stroke="#2b5878" stroke-width="2"><rect x="12" y="16" width="40" height="26" rx="3"/><path d="M24 50h16M32 42v8"/><circle cx="32" cy="29" r="6"/></svg>`
};
const MEDIA_CLASS = {
  "Health & Beauty":"media--beauty", "Home & Kitchen":"media--home",
  "Watches":"media--watch", "Fragrance":"media--fragrance", "Electronics":"media--electronics"
};

/* ---------- PRODUCT CATALOG (placeholder data — swap in real SKUs) ---------- */
const PRODUCTS = [
  { id:1, cat:"Health & Beauty", title:"Ultra Vital Glutathione Capsules 30s", price:6900, was:9400, rating:4.6, badge:"-27%",
    desc:"A daily brightening and antioxidant capsule formulated to support even-toned, radiant skin from within.",
    bullets:["30 capsules per bottle, one-a-day dose","Combined with Vitamin C for absorption","Dermatologically tested, non-drowsy"] },
  { id:2, cat:"Health & Beauty", title:"Overnight Acne Spot Gel 20g", price:2450, was:3200, rating:4.4, badge:"-23%",
    desc:"A targeted spot treatment that works while you sleep to calm redness and clear blemishes by morning.",
    bullets:["Salicylic acid + tea tree formula","Fragrance-free, suitable for sensitive skin","Visible results in 3–5 nights"] },
  { id:3, cat:"Health & Beauty", title:"Daily Repair Moisturizing Cream 89ml", price:5950, was:7999, rating:4.8, badge:"-25%",
    desc:"A lightweight ceramide-rich moisturizer that restores the skin barrier and locks in hydration for 24 hours.",
    bullets:["With 3 essential ceramides","Fragrance-free, non-comedogenic","Dermatologist developed"] },
  { id:4, cat:"Health & Beauty", title:"Toleriane Double Repair Face Moisturizer 25ml", price:4650, was:5900, rating:4.7, badge:"-21%",
    desc:"A gentle, fast-absorbing moisturizer for sensitive skin, formulated with thermal spring water and niacinamide.",
    bullets:["24h hydration, non-greasy finish","Suitable for sensitive & reactive skin","Fragrance-free"] },
  { id:5, cat:"Home & Kitchen", title:"5-Layer Stainless Steel Cookware Set", price:18900, was:24500, rating:4.5, badge:"-23%",
    desc:"A complete cookware set with even heat distribution, designed for everyday stovetop cooking.",
    bullets:["7 pieces incl. lids","Induction compatible","Dishwasher safe"] },
  { id:6, cat:"Home & Kitchen", title:"Digital Air Fryer 5.5L", price:14200, was:17800, rating:4.6, badge:"-20%",
    desc:"Crisp, golden results with up to 85% less oil. Eight preset digital cooking programs.",
    bullets:["5.5 litre non-stick basket","8 preset programs","Auto shut-off timer"] },
  { id:7, cat:"Home & Kitchen", title:"Ceramic Non-Stick Pan, 28cm", price:4300, was:5600, rating:4.3, badge:"-23%",
    desc:"A PFOA-free ceramic pan that heats evenly and releases food effortlessly.",
    bullets:["Ceramic non-stick coating","Compatible with all stovetops","Soft-touch heat-resistant handle"] },
  { id:8, cat:"Home & Kitchen", title:"Cordless Handheld Vacuum Cleaner", price:9800, was:12900, rating:4.4, badge:"-24%",
    desc:"Lightweight cordless vacuum with strong suction for quick clean-ups around the home and car.",
    bullets:["Up to 30 min runtime","Washable HEPA filter","Includes 3 attachments"] },
  { id:9, cat:"Watches", title:"Chrono Classic Steel Watch — Men", price:8900, was:12500, rating:4.7, badge:"-29%",
    desc:"A stainless steel chronograph with sapphire-coated crystal and 5 ATM water resistance.",
    bullets:["Quartz chronograph movement","5 ATM water resistant","Stainless steel strap"] },
  { id:10, cat:"Watches", title:"Minimalist Leather Strap Watch — Women", price:6400, was:8200, rating:4.5, badge:"-22%",
    desc:"A slim-profile watch with a genuine leather strap, designed for everyday minimal wear.",
    bullets:["Slim 8mm case","Genuine leather strap","3 ATM water resistant"] },
  { id:11, cat:"Fragrance", title:"Aura Intense EDP for Men, 100ml", price:6599, was:7999, rating:4.8, badge:"-18%",
    desc:"A bold, woody-amber fragrance built around cedar, tonka bean and a hint of black pepper.",
    bullets:["100ml Eau de Parfum","8–10 hour longevity","Woody amber fragrance family"] },
  { id:12, cat:"Fragrance", title:"Pacific Bloom EDP for Women, 90ml", price:5800, was:7400, rating:4.6, badge:"-22%",
    desc:"A fresh floral-fruity scent with notes of white peach, jasmine and soft musk.",
    bullets:["90ml Eau de Parfum","Floral-fruity fragrance family","Long-lasting sillage"] },
  { id:13, cat:"Electronics", title:"Pressure Tech Bluetooth Earbuds", price:4990, was:6500, rating:4.4, badge:"-24%",
    desc:"Crystal-clear stereo sound with a wide soundfield, waterproof housing and a digital charging case display.",
    bullets:["Waterproof, sweat-resistant","LED battery display on case","Automatic fast pairing"] },
  { id:14, cat:"Electronics", title:"10000mAh Fast-Charge Power Bank", price:3450, was:4300, rating:4.5, badge:"-20%",
    desc:"Compact power bank with dual-port fast charging, enough for 2+ full phone charges.",
    bullets:["10000mAh capacity","Dual USB output","LED charge indicator"] },
  { id:15, cat:"Health & Beauty", title:"Vitamin C Brightening Serum 30ml", price:3900, was:5200, rating:4.6, badge:"-25%",
    desc:"A 15% Vitamin C serum that targets dullness and uneven tone for a brighter complexion over time.",
    bullets:["15% stabilized Vitamin C","Lightweight, fast-absorbing","Use AM under sunscreen"] },
  { id:16, cat:"Home & Kitchen", title:"Electric Kettle, 1.7L Stainless Steel", price:3800, was:4900, rating:4.5, badge:"-22%",
    desc:"A fast-boil stainless steel kettle with auto shut-off and boil-dry protection.",
    bullets:["1.7 litre capacity","Auto shut-off + boil-dry protection","360° cordless base"] },
];

/* ---------- STATE (persisted in localStorage so cart/wishlist survive reloads) ---------- */
function loadState(){
  try{
    const savedCart = JSON.parse(localStorage.getItem("zm_cart") || "[]");
    const savedWish = JSON.parse(localStorage.getItem("zm_wishlist") || "[]");
    return { cart: Array.isArray(savedCart) ? savedCart : [], wishlist: new Set(savedWish) };
  }catch(e){ return { cart: [], wishlist: new Set() }; }
}
function saveState(){
  try{
    localStorage.setItem("zm_cart", JSON.stringify(state.cart));
    localStorage.setItem("zm_wishlist", JSON.stringify(Array.from(state.wishlist)));
  }catch(e){ /* storage unavailable, fail silently */ }
}
const state = loadState();

/* ---------- HELPERS ---------- */
const rupees = n => "Rs. " + n.toLocaleString("en-PK");
const findProduct = id => PRODUCTS.find(p => p.id === Number(id));
const qs = (sel, el=document) => el.querySelector(sel);
const qsa = (sel, el=document) => Array.from(el.querySelectorAll(sel));

function mediaBlock(cat, extraClass=""){
  return `<div class="${extraClass} ${MEDIA_CLASS[cat]}" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;">${ICONS[cat]}</div>`;
}

function toast(msg){
  const t = qs("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._timer);
  toast._timer = setTimeout(()=>t.classList.remove("show"), 2200);
}

function stars(rating){
  const full = Math.round(rating);
  return "★".repeat(full) + "☆".repeat(5-full);
}

/* ---------- CART / WISHLIST LOGIC ---------- */
function addToCart(id, qty=1){
  const existing = state.cart.find(i => i.id === id);
  if(existing){ existing.qty += qty; }
  else { state.cart.push({ id, qty }); }
  saveState();
  renderCartBadges();
  renderCartDrawer();
  toast("Added to cart");
}
function removeFromCart(id){
  state.cart = state.cart.filter(i => i.id !== id);
  saveState();
  renderCartBadges(); renderCartDrawer();
  if(location.pathname.replace(/\/+$/,"") === "/cart") render();
}
function setQty(id, qty){
  const item = state.cart.find(i => i.id === id);
  if(!item) return;
  item.qty = Math.max(1, qty);
  saveState();
  renderCartBadges(); renderCartDrawer();
  if(location.pathname.replace(/\/+$/,"") === "/cart") render();
}
function cartTotal(){
  return state.cart.reduce((sum, i) => sum + findProduct(i.id).price * i.qty, 0);
}
function cartCount(){
  return state.cart.reduce((sum, i) => sum + i.qty, 0);
}
function toggleWishlist(id){
  if(state.wishlist.has(id)) state.wishlist.delete(id);
  else state.wishlist.add(id);
  saveState();
  renderCartBadges();
  toast(state.wishlist.has(id) ? "Added to wishlist" : "Removed from wishlist");
}

function renderCartBadges(){
  qs("#cartCount").textContent = cartCount();
  qs("#wishCount").textContent = state.wishlist.size;
}

function renderCartDrawer(){
  const wrap = qs("#cartItems");
  if(state.cart.length === 0){
    wrap.innerHTML = `<div class="empty-cart">Your cart is empty.<br>Browse the catalog to add something you like.</div>`;
  } else {
    wrap.innerHTML = state.cart.map(i => {
      const p = findProduct(i.id);
      return `
      <div class="mini-row">
        <div class="mini-row__media">${mediaBlock(p.cat)}</div>
        <div>
          <div class="mini-row__title">${p.title}</div>
          <div class="mini-row__ctrl">
            <button data-qty-down="${p.id}">−</button>
            <span>${i.qty}</span>
            <button data-qty-up="${p.id}">+</button>
          </div>
        </div>
        <div>
          <div class="mini-row__price">${rupees(p.price * i.qty)}</div>
          <button class="cart-row__remove" data-remove="${p.id}">Remove</button>
        </div>
      </div>`;
    }).join("");
  }
  qs("#cartSubtotal").textContent = rupees(cartTotal());

  wrap.onclick = e => {
    const up = e.target.closest("[data-qty-up]");
    const down = e.target.closest("[data-qty-down]");
    const rm = e.target.closest("[data-remove]");
    if(up){ const item = state.cart.find(i=>i.id===Number(up.dataset.qtyUp)); setQty(item.id, item.qty+1); }
    if(down){ const item = state.cart.find(i=>i.id===Number(down.dataset.qtyDown)); setQty(item.id, item.qty-1); }
    if(rm){ removeFromCart(Number(rm.dataset.remove)); }
  };
}


/* ---------- CLEAN SEO URL HELPERS ---------- */
const slugify = text => String(text).toLowerCase().trim().replace(/&/g,"and").replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"");
const productPath = p => `/product/${slugify(p.title)}/`;
const categoryPath = c => `/category/${slugify(c)}/`;
const policyPath = k => `/policy/${k}/`;
const productBySlug = slug => PRODUCTS.find(p => slugify(p.title) === slug);
const categoryBySlug = slug => ["Health & Beauty","Home & Kitchen","Watches","Fragrance","Electronics"].find(c => slugify(c) === slug);

function setMeta({title, description, canonical, type="website", image=""}={}){
  document.title = title || "ZM Hybrid Store";
  const set = (sel, attr, value, create) => {
    let el = document.head.querySelector(sel);
    if(!el && create){ el=document.createElement(create.tag); create.attrs.forEach(([k,v])=>el.setAttribute(k,v)); document.head.appendChild(el); }
    if(el) el.setAttribute(attr, value);
  };
  set('meta[name="description"]','content',description||"Shop beauty, home, watches, fragrance and electronics at ZM Hybrid Store.",{tag:'meta',attrs:[['name','description']]});
  set('meta[property="og:title"]','content',document.title,{tag:'meta',attrs:[['property','og:title']]});
  set('meta[property="og:description"]','content',description||"Shop quality products at ZM Hybrid Store.",{tag:'meta',attrs:[['property','og:description']]});
  set('meta[property="og:type"]','content',type,{tag:'meta',attrs:[['property','og:type']]});
  if(image) set('meta[property="og:image"]','content',image,{tag:'meta',attrs:[['property','og:image']]});
  let can=document.head.querySelector('link[rel="canonical"]');
  if(!can){can=document.createElement('link');can.rel='canonical';document.head.appendChild(can);}
  can.href = canonical || (location.origin + location.pathname);
}
function setProductSchema(p){
  const old=document.getElementById('productSchema'); if(old) old.remove();
  const schema=document.createElement('script'); schema.type='application/ld+json'; schema.id='productSchema';
  schema.textContent=JSON.stringify({
    "@context":"https://schema.org","@type":"Product","name":p.title,"description":p.desc,
    "category":p.cat,"sku":"ZM-"+p.id,"offers":{"@type":"Offer","priceCurrency":"PKR","price":p.price,"availability":"https://schema.org/InStock","url":location.origin+productPath(p)}
  });
  document.head.appendChild(schema);
}
function clearProductSchema(){ const old=document.getElementById('productSchema'); if(old) old.remove(); }

/* ---------- ROUTER ---------- */
function parseRoute(){
  const clean = location.pathname.replace(/\/+$/, "") || "/";
  const params = new URLSearchParams(location.search || "");
  if(clean === "/" || clean === "/home") return {route:"home", params};
  if(clean === "/catalog") return {route:"catalog", params};
  if(clean.startsWith("/category/")){ const slug=clean.split("/")[2]||""; const cat=categoryBySlug(slug); if(cat) params.set("cat",cat); return {route:"catalog",params,category:cat}; }
  if(clean.startsWith("/product/")){ const slug=clean.split("/")[2]||""; return {route:"product",product:productBySlug(slug)}; }
  if(clean === "/product") { const p=findProduct(params.get("id")); return {route:"product",product:p}; }
  if(clean === "/cart") return {route:"cart",params};
  if(clean === "/checkout") return {route:"checkout",params};
  if(clean === "/contact") return {route:"contact",params};
  if(clean.startsWith("/policy/")) return {route:"policy",key:clean.split("/")[2]||"",params};
  return {route:"404",params};
}
function render(){
  const r=parseRoute(), app=qs("#app");
  window.scrollTo(0,0); closeCartDrawer(); closeSearch();
  qsa(".main-nav a").forEach(a=>a.classList.remove("active"));
  clearProductSchema();
  if(r.route==="home"){ app.innerHTML=viewHome(); wireHome(); markNav("/"); setMeta({title:"ZM Hybrid Store — Beauty, Home & Lifestyle Essentials",description:"Shop skincare, home & kitchen upgrades, watches, fragrance and electronics at ZM Hybrid Store. Cash on delivery available across Pakistan."}); }
  else if(r.route==="catalog"){ app.innerHTML=viewCatalog(r.params); wireCatalog(r.params); setMeta({title:(r.category||r.params.get("cat")||"All Products")+" — ZM Hybrid Store",description:`Shop ${r.category||r.params.get("cat")||"quality products"} at ZM Hybrid Store. Browse products, prices and delivery options.`}); }
  else if(r.route==="product"){ const p=r.product; app.innerHTML=viewProduct(p?.id); wireProduct(p?.id); if(p){setMeta({title:`${p.title} — ZM Hybrid Store`,description:p.desc,canonical:location.origin+productPath(p),type:"product"});setProductSchema(p);} }
  else if(r.route==="cart"){ app.innerHTML=viewCartPage(); wireCartPage(); setMeta({title:"Your Cart — ZM Hybrid Store",description:"Review your ZM Hybrid Store cart before checkout."}); }
  else if(r.route==="checkout"){ app.innerHTML=viewCheckout(); wireCheckout(); setMeta({title:"Checkout — ZM Hybrid Store",description:"Securely submit your shipping details and choose your payment method."}); }
  else if(r.route==="contact"){ app.innerHTML=viewContact(); wireContact(); markNav("/contact"); setMeta({title:"Contact — ZM Hybrid Store",description:"Contact ZM Hybrid Store about products, orders, shipping and returns."}); }
  else if(r.route==="policy"){ app.innerHTML=viewPolicy(r.key); setMeta({title:(POLICY[r.key]?.title||"Policy")+" — ZM Hybrid Store",description:"ZM Hybrid Store customer policy and service information."}); }
  else { app.innerHTML=`<div class="container section"><h2>Page not found</h2><a href="/catalog/" data-link class="btn btn--dark">Back to catalog</a></div>`; setMeta({title:"Page Not Found — ZM Hybrid Store",description:"The requested page could not be found."}); }
}
function markNav(href){ const link=qsa(".main-nav a").find(a=>a.getAttribute("href")===href); if(link) link.classList.add("active"); }
window.addEventListener("popstate", render);
/* ---------- VIEW: HOME ---------- */
function viewHome(){
  const featured = PRODUCTS.slice(0, 8);
  const cats = ["Health & Beauty","Home & Kitchen","Watches","Fragrance","Electronics"];
  return `
  <section class="hero">
    <div class="hero__inner">
      <div>
        <div class="hero__eyebrow"><span class="dot"></span> SALE IS LIVE — UP TO 50% OFF</div>
        <h1>Beauty and home<br>essentials, done <em>right</em>.</h1>
        <p class="lede">Curated skincare, kitchen upgrades, watches and fragrance — vetted for quality, priced fairly, delivered fast across the country.</p>
        <div class="hero__cta">
          <a href="/catalog/" class="btn btn--primary" data-link>Shop the sale</a>
          <a href="/category/health-and-beauty/" class="btn btn--outline" style="border-color:#fff;color:#fff;" data-link>Explore beauty</a>
        </div>
        <div class="hero__stats"><div><strong>COD</strong><span>available nationwide</span></div><div><strong>2–5</strong><span>business day delivery</span></div><div><strong>7-day</strong><span>return window</span></div></div>
        <p class="hero__urdu">کیش آن ڈیلیوری، اصلی پروڈکٹس اور تیز ترسیل — پاکستان بھر میں</p>
      </div>
      <div class="hero__art"><div class="ring"></div>${ICONS["Health & Beauty"].replace('#6E1423','#F1C77A')}</div>
    </div>
  </section>

  <section class="features">
    <div class="features__inner">
      <div class="feature"><div class="feature__icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M3 8h11v9H3zM14 11h4l3 3v3h-7z" stroke="currentColor" stroke-width="1.8"/><circle cx="7" cy="19" r="1.6" stroke="currentColor" stroke-width="1.8"/><circle cx="17" cy="19" r="1.6" stroke="currentColor" stroke-width="1.8"/></svg></div><div><h4>Free shipping <span class="ur">مفت ترسیل</span></h4><p>On every order, no minimum spend.</p></div></div>
      <div class="feature"><div class="feature__icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M4 12a8 8 0 1 1 3 6.2M4 12v5M4 12H9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></div><div><h4>Cash on delivery <span class="ur">کیش آن ڈیلیوری</span></h4><p>Pay when your order arrives — nationwide.</p></div></div>
      <div class="feature"><div class="feature__icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M12 3a9 9 0 1 0 9 9M12 3v9l6 3" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></div><div><h4>Support on WhatsApp <span class="ur">واٹس ایپ سپورٹ</span></h4><p>Message us anytime, we reply fast.</p></div></div>
    </div>
  </section>

  <section class="section container">
    <div class="section-head">
      <div><h2>Trending categories</h2><p>Shop what's moving this week.</p></div>
    </div>
    <div class="cat-tabs" id="homeCatTabs">
      ${cats.map((c,i)=>`<a href="${categoryPath(c)}" class="cat-tab" data-link>${c}</a>`).join("")}
    </div>
    <div class="grid" id="homeGrid">
      ${featured.map(productCard).join("")}
    </div>
  </section>

  <section class="container section--tight">
    <div class="banner-split">
      <div class="banner-card banner-card--a">
        <h3>Skincare edit</h3>
        <p>Barrier-repair creams and daily actives, up to 27% off.</p>
        <a href="/category/health-and-beauty/" class="btn btn--outline" style="border-color:#fff;color:#fff;" data-link>Shop beauty</a>
      </div>
      <div class="banner-card banner-card--b">
        <h3>Watches &amp; fragrance</h3>
        <p>Everyday pieces built to last, from Rs. 5,800.</p>
        <a href="/category/watches/" class="btn btn--outline" style="border-color:#fff;color:#fff;" data-link>Shop now</a>
      </div>
    </div>
  </section>

  <section class="trust"><div class="trust__inner"><div class="trust-card"><div class="stars">★★★★★</div><p>Customer reviews will appear here as verified orders and genuine feedback come in.</p><strong>Verified reviews coming soon</strong></div><div class="trust-card"><div class="stars">✓</div><p>Cash on delivery, WhatsApp support and clear delivery/return policies.</p><strong>Transparent shopping</strong></div><div class="trust-card"><div class="stars">✓</div><p>Product information and pricing are shown clearly before checkout.</p><strong>Shop with confidence</strong></div></div></section>

  <section class="container section">
    <div class="section-head">
      <div><h2>Fresh arrivals</h2><p>New in this week, across every category.</p></div>
      <a href="/catalog/" class="btn btn--dark" data-link>View all products</a>
    </div>
    <div class="grid">
      ${PRODUCTS.slice(8,16).map(productCard).join("")}
    </div>
  </section>
  `;
}
function wireHome(){ wireCardEvents(qs("#app")); }

/* ---------- PRODUCT CARD (shared) ---------- */
function productCard(p){
  const isWish = state.wishlist.has(p.id);
  return `
  <div class="card">
    <div class="card__media ${MEDIA_CLASS[p.cat]}">
      <span class="card__badge">${p.badge}</span>
      <button class="card__wish ${isWish?'active':''}" data-wish="${p.id}" aria-label="Toggle wishlist">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="${isWish?'currentColor':'none'}"><path d="M12 20s-7.5-4.6-10-9.3C.6 7 2.4 3.6 6 3.2c2-.2 3.7.9 6 3.3 2.3-2.4 4-3.5 6-3.3 3.6.4 5.4 3.8 4 7.5C19.5 15.4 12 20 12 20z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
      </button>
      ${ICONS[p.cat]}
    </div>
    <div class="card__body">
      <span class="card__cat">${p.cat}</span>
      <div class="card__title"><a href="${productPath(p)}" data-link>${p.title}</a></div>
      <div class="card__price"><span class="now">${rupees(p.price)}</span><span class="was">${rupees(p.was)}</span></div>
      <button class="card__add" data-add="${p.id}">Add to cart</button>
    </div>
  </div>`;
}
function wireCardEvents(root){
  qsa("[data-add]", root).forEach(btn => btn.addEventListener("click", () => addToCart(Number(btn.dataset.add), 1)));
  qsa("[data-wish]", root).forEach(btn => btn.addEventListener("click", () => { toggleWishlist(Number(btn.dataset.wish)); render(); }));
}

/* ---------- VIEW: CATALOG ---------- */
function viewCatalog(params){
  const activeCat = params.get("cat") || "";
  const q = (params.get("q") || "").toLowerCase();
  const sort = params.get("sort") || "featured";
  const cats = ["Health & Beauty","Home & Kitchen","Watches","Fragrance","Electronics"];

  let items = PRODUCTS.filter(p => (!activeCat || p.cat === activeCat) && (!q || p.title.toLowerCase().includes(q)));
  if(sort === "price-asc") items = [...items].sort((a,b)=>a.price-b.price);
  if(sort === "price-desc") items = [...items].sort((a,b)=>b.price-a.price);
  if(sort === "rating") items = [...items].sort((a,b)=>b.rating-a.rating);

  return `
  <div class="container section">
    <div class="breadcrumb"><a href="/" data-link>Home</a> / Catalog${activeCat ? " / " + activeCat : ""}</div>
    <div class="page-head">
      <h1>${activeCat || "All products"}</h1>
      <p>${q ? `Results for "${q}"` : "Browse the full range — filter by category or sort to find what you need."}</p>
    </div>
    <div class="catalog-layout">
      <aside class="filters">
        <div class="filter-group">
          <h4>Category</h4>
          <label class="filter-opt"><input type="radio" name="cat" value="" ${!activeCat?'checked':''}> All categories</label>
          ${cats.map(c => `<label class="filter-opt"><input type="radio" name="cat" value="${c}" ${activeCat===c?'checked':''}> ${c}</label>`).join("")}
        </div>
      </aside>
      <div>
        <div class="catalog-toolbar">
          <span class="result-count">${items.length} product${items.length!==1?'s':''}</span>
          <select id="sortSelect">
            <option value="featured" ${sort==='featured'?'selected':''}>Sort: Featured</option>
            <option value="price-asc" ${sort==='price-asc'?'selected':''}>Price: Low to High</option>
            <option value="price-desc" ${sort==='price-desc'?'selected':''}>Price: High to Low</option>
            <option value="rating" ${sort==='rating'?'selected':''}>Top Rated</option>
          </select>
        </div>
        <div class="grid" id="catalogGrid">
          ${items.length ? items.map(productCard).join("") : `<div class="empty-state" style="grid-column:1/-1">No products match your search. <br><a href="/catalog/" data-link style="text-decoration:underline;">Clear filters</a></div>`}
        </div>
      </div>
    </div>
  </div>`;
}
function wireCatalog(params){
  wireCardEvents(qs("#app"));
  qsa('input[name="cat"]').forEach(r => r.addEventListener("change", () => {
    const p = new URLSearchParams(location.search || "");
    if(r.value) p.set("cat", r.value); else p.delete("cat");
    history.pushState({}, "", "/catalog/?" + p.toString()); render();
  }));
  qs("#sortSelect").addEventListener("change", e => {
    const p = new URLSearchParams(location.search || "");
    p.set("sort", e.target.value);
    history.pushState({}, "", "/catalog/?" + p.toString()); render();
  });
}

/* ---------- VIEW: PRODUCT DETAIL ---------- */
function viewProduct(id){
  const p = findProduct(id);
  if(!p) return `<div class="container section"><h2>Product not found</h2><a href="/catalog/" data-link class="btn btn--dark">Back to catalog</a></div>`;
  const related = PRODUCTS.filter(x => x.cat === p.cat && x.id !== p.id).slice(0,4);
  const offPct = Math.round((1 - p.price/p.was) * 100);
  const isWish = state.wishlist.has(p.id);

  return `
  <div class="container section">
    <div class="breadcrumb"><a href="/" data-link>Home</a> / <a href="${categoryPath(p.cat)}" data-link>${p.cat}</a> / ${p.title}</div>
    <div class="pdp">
      <div class="pdp__gallery">
        <div class="pdp__main-media ${MEDIA_CLASS[p.cat]}">${ICONS[p.cat]}</div>
        <div class="pdp__thumbs">
          ${[0,1,2].map(i => `<div class="pdp__thumb ${i===0?'active':''} ${MEDIA_CLASS[p.cat]}">${ICONS[p.cat]}</div>`).join("")}
        </div>
      </div>
      <div class="pdp__info">
        <div class="pdp__cat">${p.cat.toUpperCase()}</div>
        <h1>${p.title}</h1>
        <div class="pdp__price">
          <span class="now">${rupees(p.price)}</span>
          <span class="was">${rupees(p.was)}</span>
          <span class="off">-${offPct}%</span>
        </div>
        <div class="pdp__viewers">${stars(p.rating)} (${p.rating}) · Customer rating</div>

        <div class="pdp__banner">SUMMER SALE — UP TO 50% OFF · ENDS SOON</div>

        <div class="qty-row">
          <div class="qty-selector">
            <button id="qtyMinus">−</button>
            <span id="qtyVal">1</span>
            <button id="qtyPlus">+</button>
          </div>
          <span class="stock-note">In stock, ships within 24 hours</span>
        </div>

        <div class="pdp__actions">
          <button class="btn btn--outline" id="addCartBtn">Add to cart</button>
          <button class="btn btn--primary" id="buyNowBtn">Buy it now</button>
          <button class="icon-fav ${isWish?'active':''}" id="favBtn" aria-label="Wishlist">
            <svg width="19" height="19" viewBox="0 0 24 24" fill="${isWish?'currentColor':'none'}"><path d="M12 20s-7.5-4.6-10-9.3C.6 7 2.4 3.6 6 3.2c2-.2 3.7.9 6 3.3 2.3-2.4 4-3.5 6-3.3 3.6.4 5.4 3.8 4 7.5C19.5 15.4 12 20 12 20z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>
          </button>
        </div>

        <div class="pdp__perks">
          <div class="pdp__perk"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M3 8h11v9H3zM14 11h4l3 3v3h-7z" stroke="currentColor" stroke-width="1.8"/></svg> Free shipping on this item, delivered in 2–5 business days</div>
          <div class="pdp__perk"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M4 12a8 8 0 1 1 3 6.2M4 12v5M4 12H9" stroke="currentColor" stroke-width="1.8"/></svg> 7-day free returns if it's not right for you</div>
          <div class="pdp__perk"><svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M12 3l7 4v5c0 5-3.4 8.4-7 9-3.6-.6-7-4-7-9V7l7-4z" stroke="currentColor" stroke-width="1.8"/></svg> Secure checkout, cash on delivery available</div>
        </div>

        <div class="pdp__tabs">
          <div class="pdp__tab-heads">
            <button class="pdp__tab-head active" data-tab="desc">Description</button>
            <button class="pdp__tab-head" data-tab="details">Details</button>
            <button class="pdp__tab-head" data-tab="shipping">Shipping</button>
          </div>
          <div class="pdp__tab-panel active" data-panel="desc"><p>${p.desc}</p></div>
          <div class="pdp__tab-panel" data-panel="details"><ul>${p.bullets.map(b=>`<li>${b}</li>`).join("")}</ul></div>
          <div class="pdp__tab-panel" data-panel="shipping"><p>Orders ship within 24 hours and arrive in 2–5 business days depending on your city. Cash on delivery is available nationwide; prepaid orders receive priority dispatch. Free 7-day returns on unused items in original packaging.</p></div>
        </div>
      </div>
    </div>

    ${related.length ? `
    <div class="section-head" style="margin-top:64px;">
      <div><h2>You may also like</h2><p>More from ${p.cat}.</p></div>
    </div>
    <div class="grid">${related.map(productCard).join("")}</div>` : ""}
  </div>`;
}
function wireProduct(id){
  const p = findProduct(id);
  if(!p) return;
  const app = qs("#app");
  let qty = 1;
  const qtyVal = qs("#qtyVal");
  qs("#qtyPlus").addEventListener("click", () => { qty++; qtyVal.textContent = qty; });
  qs("#qtyMinus").addEventListener("click", () => { qty = Math.max(1, qty-1); qtyVal.textContent = qty; });
  qs("#addCartBtn").addEventListener("click", () => addToCart(p.id, qty));
  qs("#buyNowBtn").addEventListener("click", () => { addToCart(p.id, qty); history.pushState({}, "", "/checkout/"); render(); });
  qs("#favBtn").addEventListener("click", () => { toggleWishlist(p.id); render(); });

  qsa(".pdp__tab-head", app).forEach(btn => btn.addEventListener("click", () => {
    qsa(".pdp__tab-head", app).forEach(b => b.classList.remove("active"));
    qsa(".pdp__tab-panel", app).forEach(pnl => pnl.classList.remove("active"));
    btn.classList.add("active");
    qs(`[data-panel="${btn.dataset.tab}"]`, app).classList.add("active");
  }));

  wireCardEvents(app);
}

/* ---------- VIEW: CART PAGE ---------- */
function viewCartPage(){
  if(state.cart.length === 0){
    return `
    <div class="container section">
      <div class="empty-state">
        <h2 style="margin-bottom:12px;">Your cart is empty</h2>
        <p style="margin-bottom:24px;">Looks like you haven't added anything yet.</p>
        <a href="/catalog/" class="btn btn--primary" data-link>Start shopping</a>
      </div>
    </div>`;
  }
  const rows = state.cart.map(i => {
    const p = findProduct(i.id);
    return `
    <div class="cart-row">
      <div class="cart-row__media ${MEDIA_CLASS[p.cat]}">${ICONS[p.cat]}</div>
      <div>
        <div class="cart-row__title"><a href="${productPath(p)}" data-link>${p.title}</a></div>
        <div class="cart-row__cat">${p.cat}</div>
        <button class="cart-row__remove" data-remove="${p.id}">Remove</button>
      </div>
      <div class="qty-selector">
        <button data-qty-down="${p.id}">−</button><span>${i.qty}</span><button data-qty-up="${p.id}">+</button>
      </div>
      <div class="cart-row__price">${rupees(p.price * i.qty)}</div>
    </div>`;
  }).join("");

  const subtotal = cartTotal();
  const shipping = 0;
  return `
  <div class="container section">
    <div class="page-head"><h1>Your cart</h1><p>${cartCount()} item${cartCount()!==1?'s':''} ready for checkout.</p></div>
    <div class="cart-page">
      <div>${rows}</div>
      <div class="order-summary">
        <h3>Order summary</h3>
        <div class="summary-line"><span>Subtotal</span><strong>${rupees(subtotal)}</strong></div>
        <div class="summary-line"><span>Shipping</span><strong>${shipping === 0 ? "Free" : rupees(shipping)}</strong></div>
        <div class="summary-total"><span>Total</span><span>${rupees(subtotal + shipping)}</span></div>
        <a href="/checkout/" class="btn btn--primary btn--block" data-link style="margin-top:18px;">Proceed to checkout</a>
        <a href="/catalog/" class="btn btn--outline btn--block" data-link style="margin-top:10px;">Continue shopping</a>
      </div>
    </div>
  </div>`;
}
function wireCartPage(){
  const app = qs("#app");
  app.onclick = e => {
    const up = e.target.closest("[data-qty-up]");
    const down = e.target.closest("[data-qty-down]");
    const rm = e.target.closest("[data-remove]");
    if(up){ const item = state.cart.find(i=>i.id===Number(up.dataset.qtyUp)); setQty(item.id, item.qty+1); }
    if(down){ const item = state.cart.find(i=>i.id===Number(down.dataset.qtyDown)); setQty(item.id, item.qty-1); }
    if(rm){ removeFromCart(Number(rm.dataset.remove)); }
  };
}

/* ---------- VIEW: CHECKOUT ---------- */
function viewCheckout(){
  if(state.cart.length === 0){
    return `<div class="container section"><div class="empty-state"><h2>Your cart is empty</h2><p style="margin-bottom:20px;">Add a product before checking out.</p><a href="/catalog/" class="btn btn--primary" data-link>Browse products</a></div></div>`;
  }
  const subtotal = cartTotal();
  return `
  <div class="container section">
    <div class="page-head"><h1>Checkout</h1><p>Enter your shipping details to complete your order.</p></div>
    <form class="checkout-layout" id="checkoutForm">
      <div>
        <div class="form-row">
          <div class="form-group"><label>First name</label><input id="ckFirstName" required></div>
          <div class="form-group"><label>Last name</label><input id="ckLastName" required></div>
        </div>
        <div class="form-group"><label>Phone number</label><input id="ckPhone" type="tel" required placeholder="03xx-xxxxxxx"></div>
        <div class="form-group"><label>Address</label><input id="ckAddress" required placeholder="House no, street, area"></div>
        <div class="form-row">
          <div class="form-group"><label>City <span class="ur">شہر</span></label>
            <select id="ckCity" required>
              <option value="" disabled selected>Select your city</option>
              <option>Karachi</option><option>Lahore</option><option>Islamabad</option>
              <option>Rawalpindi</option><option>Faisalabad</option><option>Multan</option>
              <option>Peshawar</option><option>Quetta</option><option>Sialkot</option>
              <option>Gujranwala</option><option>Hyderabad</option><option>Sargodha</option>
              <option>Other</option>
            </select>
          </div>
          <div class="form-group"><label>Postal code</label><input id="ckPostal"></div>
        </div>
        <div class="form-group"><label>Order notes (optional)</label><textarea id="ckNotes" rows="3"></textarea></div>

        <h4 style="font-size:.85rem;text-transform:uppercase;letter-spacing:.05em;color:var(--ink-soft);margin:22px 0 6px;">Payment method</h4>
        <div class="pay-methods">
          <label class="pay-method pay-method--recommended"><input type="radio" name="pay" value="Cash on delivery" checked> Cash on delivery <span class="ur">کیش آن ڈیلیوری</span> <span class="recommend-tag">Recommended</span></label>
          <label class="pay-method"><input type="radio" name="pay" value="Bank transfer"> Bank transfer</label>
          <label class="pay-method"><input type="radio" name="pay" value="JazzCash / Easypaisa"> JazzCash / Easypaisa <small>Manual confirmation</small></label>
        </div>
        <button type="submit" class="btn btn--primary btn--block" id="placeOrderBtn">Place order</button>
        <p style="font-size:.78rem;color:var(--ink-soft);margin-top:10px;text-align:center;">Online gateway credentials are not connected yet. Orders are confirmed through WhatsApp; prepaid methods require manual payment confirmation.</p>
      </div>

      <div class="order-summary">
        <h3>Order summary</h3>
        ${state.cart.map(i => {
          const p = findProduct(i.id);
          return `<div class="summary-mini-row">
            <div class="summary-mini-media ${MEDIA_CLASS[p.cat]}">${ICONS[p.cat]}</div>
            <div style="flex:1;">
              <div style="font-weight:700;">${p.title}</div>
              <div style="color:var(--ink-soft);">Qty ${i.qty}</div>
            </div>
            <div style="font-weight:800;color:var(--maroon);">${rupees(p.price*i.qty)}</div>
          </div>`;
        }).join("")}
        <div class="summary-line" style="margin-top:16px;"><span>Subtotal</span><strong>${rupees(subtotal)}</strong></div>
        <div class="summary-line"><span>Shipping</span><strong>Free</strong></div>
        <div class="summary-total"><span>Total</span><span>${rupees(subtotal)}</span></div>
      </div>
    </form>
  </div>`;
}
function buildOrderText(order){
  const lines = order.items.map(i => `• ${i.title} × ${i.qty} — ${rupees(i.price * i.qty)}`).join("%0A");
  return `New order #${order.id}%0A%0A` +
    `Name: ${order.name}%0APhone: ${order.phone}%0AAddress: ${order.address}, ${order.city}%0A` +
    (order.postal ? `Postal code: ${order.postal}%0A` : "") +
    (order.notes ? `Notes: ${order.notes}%0A` : "") +
    `Payment: ${order.pay}%0A%0AItems:%0A${lines}%0A%0ATotal: ${rupees(order.total)}`;
}

async function sendOrderToSheet(order){
  if(!CONFIG.ORDER_SHEET_WEBHOOK) return;
  try{
    await fetch(CONFIG.ORDER_SHEET_WEBHOOK, {
      method: "POST",
      mode: "no-cors", // Apps Script web apps don't return CORS headers; fire-and-forget
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(order)
    });
  }catch(err){
    console.error("Order webhook failed:", err);
  }
}

function trackPurchase(order){
  if(CONFIG.GA_MEASUREMENT_ID && typeof gtag === "function"){
    gtag("event", "purchase", { transaction_id: order.id, value: order.total, currency: "PKR" });
  }
  if(CONFIG.META_PIXEL_ID && typeof fbq === "function"){
    fbq("track", "Purchase", { value: order.total, currency: "PKR" });
  }
}

function wireCheckout(){
  const form = qs("#checkoutForm");
  if(!form) return;
  form.addEventListener("submit", e => {
    e.preventDefault();
    const pay = qs('input[name="pay"]:checked').value;
    const order = {
      id: Date.now().toString().slice(-8),
      name: `${qs("#ckFirstName").value} ${qs("#ckLastName").value}`.trim(),
      phone: qs("#ckPhone").value,
      address: qs("#ckAddress").value,
      city: qs("#ckCity").value,
      postal: qs("#ckPostal").value,
      notes: qs("#ckNotes").value,
      pay,
      items: state.cart.map(i => ({ ...findProduct(i.id), qty: i.qty })),
      total: cartTotal(),
      placedAt: new Date().toISOString()
    };

    sendOrderToSheet(order);
    trackPurchase(order);

    const waLink = `https://wa.me/${CONFIG.WHATSAPP_NUMBER}?text=${buildOrderText(order)}`;
    window.open(waLink, "_blank");

    state.cart = [];
    renderCartBadges(); renderCartDrawer();
    qs("#app").innerHTML = `
      <div class="container section">
        <div class="empty-state">
          <h2 style="margin-bottom:12px;">Thanks, ${order.name.split(" ")[0]} — order #${order.id} placed 🎉</h2>
          <p style="margin-bottom:12px;">We've opened WhatsApp so you can confirm the order details with us directly.</p>
          <p style="margin-bottom:24px;">Didn't open automatically? <a href="${waLink}" target="_blank" style="text-decoration:underline;">Tap here to send it on WhatsApp</a>.</p>
          <a href="/catalog/" class="btn btn--primary" data-link>Continue shopping</a>
        </div>
      </div>`;
  });
}

/* ---------- VIEW: CONTACT ---------- */
function viewContact(){
  return `
  <div class="container section">
    <div class="page-head"><h1>Get in touch</h1><p>Questions about an order, a product, or a return? We usually reply within a few hours.</p></div>
    <div class="contact-layout">
      <div>
        <div class="contact-info-item">
          <div class="icon-circle"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 6h16v12H4z" stroke="currentColor" stroke-width="1.8"/><path d="M4 7l8 6 8-6" stroke="currentColor" stroke-width="1.8"/></svg></div>
          <div><h4>Email</h4><p>support@zmhybridstore.example</p></div>
        </div>
        <div class="contact-info-item">
          <div class="icon-circle"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M4 5c0 8 7 15 15 15l3-4-6-3-2 2c-2-1-4-3-5-5l2-2-3-6-4 0z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg></div>
          <div><h4>Phone / WhatsApp</h4><p>+92 300 0000000</p></div>
        </div>
        <div class="contact-info-item">
          <div class="icon-circle"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M12 21s7-6.3 7-12a7 7 0 1 0-14 0c0 5.7 7 12 7 12z" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="9" r="2.4" stroke="currentColor" stroke-width="1.6"/></svg></div>
          <div><h4>Hours</h4><p>Mon–Sat, 10am–7pm</p></div>
        </div>
      </div>
      <form id="contactForm">
        <div class="form-group"><label>Name</label><input required></div>
        <div class="form-group"><label>Email</label><input type="email" required></div>
        <div class="form-group"><label>Message</label><textarea rows="5" required placeholder="How can we help?"></textarea></div>
        <button type="submit" class="btn btn--primary btn--block">Send message</button>
        <p id="contactMsg" style="margin-top:12px;font-size:.85rem;color:var(--ink-soft);"></p>
      </form>
    </div>
  </div>`;
}
function wireContact(){
  const form = qs("#contactForm");
  form.addEventListener("submit", e => {
    e.preventDefault();
    qs("#contactMsg").textContent = "Thanks — your message has been sent. We'll get back to you soon.";
    form.reset();
  });
}

/* ---------- VIEW: POLICY PAGES ---------- */
const POLICY = {
  privacy:{title:"Privacy Policy",body:`<h3>Information we collect</h3><p>When you place an order or contact us, we may collect your name, phone number, email address, shipping address, city and order details needed to fulfil your request.</p><h3>How we use information</h3><p>We use order information to process and deliver orders, provide customer support, handle returns and improve the store. We do not sell customer information.</p><h3>WhatsApp and service providers</h3><p>If you choose WhatsApp confirmation, relevant order details are shared with the WhatsApp account you contact. Payment, hosting, analytics or delivery providers may process information only as needed to provide their services.</p><h3>Cookies and local storage</h3><p>This storefront uses browser local storage for cart and wishlist preferences. Optional analytics may be enabled later using the IDs configured by the store owner.</p><h3>Contact</h3><p>For privacy questions, contact the store through the contact page or the published support details.</p>`},
  terms:{title:"Terms & Conditions",body:`<h3>Orders</h3><p>An order request is subject to product availability and confirmation. Prices and promotions may change before an order is confirmed.</p><h3>Payment</h3><p>Cash on delivery is available where supported. JazzCash, Easypaisa and bank-transfer orders are treated as prepaid/manual-confirmation methods until a payment is verified.</p><h3>Products</h3><p>Product descriptions are provided to help customers make informed choices. Actual product photos, specifications and availability should be verified before launch for each SKU.</p><h3>Returns</h3><p>Returns are governed by the current Returns & Exchanges policy. Items must meet the stated eligibility requirements.</p><h3>Changes</h3><p>These terms may be updated as the store, payment methods and fulfilment arrangements change.</p>`},
  shipping:{title:"Shipping & delivery",body:`<h3>Delivery timelines</h3><p>Orders normally ship within 24 hours of confirmation and typically arrive in 2–5 business days depending on the destination and courier.</p><h3>Shipping cost</h3><p>Shipping is currently advertised as free nationwide. If this changes for a particular promotion or destination, the applicable charge will be shown before confirmation.</p><h3>Tracking</h3><p>Where courier tracking is available, tracking details will be shared after dispatch.</p>`},
  returns:{title:"Returns & exchanges",body:`<h3>Return window</h3><p>Eligible items may be returned within 7 days of delivery when unused and in original packaging.</p><h3>How to start a return</h3><p>Contact support with your order number and reason for return. We will confirm eligibility and the next steps.</p><h3>Refunds</h3><p>Approved refunds are processed after the returned item is received and inspected. Timing depends on the original payment method.</p>`},
  faq:{title:"Frequently asked questions",body:`<h3>Do you offer cash on delivery?</h3><p>Yes, COD is available nationwide where courier service supports it.</p><h3>How do I pay by JazzCash or Easypaisa?</h3><p>Select the relevant method at checkout. The order is then confirmed through WhatsApp and payment instructions can be provided manually.</p><h3>How do I track my order?</h3><p>Tracking details are shared after dispatch when available.</p><h3>Can I change my order?</h3><p>Contact support as soon as possible after ordering; changes are only possible before dispatch.</p>`}
};
function viewPolicy(key){
  const p = POLICY[key] || { title:"Not found", body:"<p>This page doesn't exist.</p>" };
  return `<div class="container section"><div class="page-head"><h1>${p.title}</h1></div><div class="policy-body">${p.body}</div></div>`;
}

/* ---------- CART DRAWER CONTROLS ---------- */
function openCartDrawer(){ qs("#cartDrawer").classList.add("open"); qs("#drawerOverlay").classList.add("open"); }
function closeCartDrawer(){ qs("#cartDrawer").classList.remove("open"); qs("#drawerOverlay").classList.remove("open"); }
qs("#cartToggle").addEventListener("click", () => { renderCartDrawer(); openCartDrawer(); });
qs("#cartClose").addEventListener("click", closeCartDrawer);
qs("#drawerOverlay").addEventListener("click", closeCartDrawer);

/* ---------- SEARCH ---------- */
function closeSearch(){ qs("#searchBar").classList.remove("open"); }
qs("#searchToggle").addEventListener("click", () => {
  qs("#searchBar").classList.toggle("open");
  if(qs("#searchBar").classList.contains("open")) qs("#searchInput").focus();
});
function doSearch(){
  const q = qs("#searchInput").value.trim();
  if(!q) return;
  history.pushState({}, "", "/catalog/?q=" + encodeURIComponent(q)); render();
}
qs("#searchGo").addEventListener("click", doSearch);
qs("#searchInput").addEventListener("keydown", e => { if(e.key === "Enter") doSearch(); });

/* ---------- WISHLIST TOGGLE (header icon just jumps to catalog view for now) ---------- */
qs("#wishToggle").addEventListener("click", () => {
  toast(state.wishlist.size ? `${state.wishlist.size} item(s) in your wishlist` : "Your wishlist is empty — tap the heart on any product");
});

/* ---------- MOBILE NAV ---------- */
qs("#navToggle").addEventListener("click", () => {
  qs("#mainNav").classList.toggle("open-mobile");
});
document.addEventListener("click", e => {
  if(e.target.closest(".main-nav a")) qs("#mainNav").classList.remove("open-mobile");
});

/* ---------- NEWSLETTER ---------- */
qs("#newsletterForm").addEventListener("submit", e => {
  e.preventDefault();
  qs("#newsletterMsg").textContent = "You're subscribed — welcome!";
  e.target.reset();
});

/* ---------- GLOBAL LINK HANDLER (keeps drawers/menus in sync) ---------- */
document.addEventListener("click", e => {
  const link = e.target.closest("[data-link]");
  if(link){ closeCartDrawer(); }
});

/* ---------- FLOATING WHATSAPP BUTTON ---------- */
qs("#waFloat").href = `https://wa.me/${CONFIG.WHATSAPP_NUMBER}?text=${encodeURIComponent("Hi! I have a question about a product on ZM Hybrid Store.")}`;

/* ---------- INIT ---------- */
renderCartBadges();
renderCartDrawer();
document.addEventListener("click", e => {
  const link=e.target.closest("a[data-link]");
  if(!link) return;
  const href=link.getAttribute("href");
  if(!href || href.startsWith("#") || href.startsWith("http")) return;
  e.preventDefault();
  history.pushState({}, "", href);
  render();
});
render();
